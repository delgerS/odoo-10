# -*- coding: utf-8 -*-

from odoo import models, fields, api
class arian(models.Model):
	""" test2 model class tree and form field declare in one class """
	_name	='arain.module'

	# name 	 	=fields.Char(string='name')
