# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

{
    'name': 'arian Industry',
    'author': 'yasir',
    'summary': 'Add Sale Module arain ',
    'website': 'bcube.pk',
    'version': '1',
    'depends': ['base','sale','account','account_accountant','purchase','report','arian_contacts_address','arian_partner','arian_product','arian_quotation','bank_details_bcube',
'beneficiary_certificate','berik_commercial_invoice','berik_pl','berik_proforma_invoice','bill_of_exchange','carton_labels',
'certificate_of_origin','commercial_invoice_arian','commercial_invoice_v4','commercial_packing_list','costing_report','covring_letter','customer_invoice_generic',
'custom_invoice_arian','custom_letter','custom_packing_list','cycle_gear_performa_invoice','employee_extension_arian','inspection_report',
'invoice_extension_arian','ixon_commercial_invoice','ixon_performa_invoice','ixon_pl','ixs_invoice','ixs_packing','product_portfolio_management_arian',
'quality_and_inspection','quotation_report','rst_commercial_invoice','rst_invoice_pl','rst_proforma_invoice','sale_order_bcube','sample_development',
'shipment_report','shipping_insructions','undertaking_report','v4_performa_invoice'],
    'data': [ 'views.xml'   
    ],
    'installable': True,
    'auto_install': False
}
