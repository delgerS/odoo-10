{
	'name': 'Work Order', 
	'description': 'Manage your Work Order changes', 
	'author': 'Muhammad Kamran', 
	'depends': ['purchase','mrp','hr','sale'], 
	'application': True,
	'data': [
	'views/template.xml'
	],
}